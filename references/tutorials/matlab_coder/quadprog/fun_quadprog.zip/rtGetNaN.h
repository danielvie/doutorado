//
// Academic License - for use in teaching, academic research, and meeting
// course requirements at degree granting institutions only.  Not for
// government, commercial, or other organizational use.
// File: rtGetNaN.h
//
// MATLAB Coder version            : 5.3
// C/C++ source code generated on  : 11-Feb-2022 01:47:26
//

#ifndef RTGETNAN_H
#define RTGETNAN_H

// Include Files
#include "rtwtypes.h"

#ifdef __cplusplus
extern "C" {
#endif

extern real_T rtGetNaN(void);
extern real32_T rtGetNaNF(void);

#ifdef __cplusplus
}
#endif
#endif
//
// File trailer for rtGetNaN.h
//
// [EOF]
//
